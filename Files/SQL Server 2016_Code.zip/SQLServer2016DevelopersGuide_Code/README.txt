Chapter 01 doesn't contain any code as authors have introduced SQL Server 2016 in that chapter.

In order to run all of the demo code in this book, you will need SQL Server 2016 Developer or Enterprise Edition. In addition, you will extensively use SQL Server Management Studio. You will also need the RStudio IDE and/or SQL Server Data Tools with R Tools for Visual Studio plug-in.
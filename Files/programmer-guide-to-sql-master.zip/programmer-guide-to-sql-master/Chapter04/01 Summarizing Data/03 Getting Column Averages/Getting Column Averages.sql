SELECT AVG(Mark) AS AverageMark
FROM StudentExam
WHERE StudentID = 10;

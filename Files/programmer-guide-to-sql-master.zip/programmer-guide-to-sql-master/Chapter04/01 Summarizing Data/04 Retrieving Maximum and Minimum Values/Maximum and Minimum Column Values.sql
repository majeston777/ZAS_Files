SELECT MAX(Mark) AS TopMark, MIN(Mark) AS BottomMark
FROM StudentExam
WHERE ExamID = 6;

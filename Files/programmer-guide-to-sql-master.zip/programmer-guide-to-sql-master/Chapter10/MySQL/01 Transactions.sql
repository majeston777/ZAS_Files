BEGIN;

INSERT INTO Student (StudentID, Name) VALUES (98, 'Anne');
INSERT INTO Student (StudentID, Name) VALUES (99, 'Julian');

ROLLBACK;


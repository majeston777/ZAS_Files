SELECT * INTO My_Friends FROM Friend
WHERE 1=0;

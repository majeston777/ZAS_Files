CREATE TABLE Friend (Name VARCHAR(50), PhoneNo VARCHAR(15));

INSERT INTO Friend (Name, PhoneNo) VALUES ('John Doe', '555 2323');
INSERT INTO Friend (Name) VALUES ('John Doe');
INSERT INTO Friend (Name, PhoneNo) VALUES ('John Doe', NULL);

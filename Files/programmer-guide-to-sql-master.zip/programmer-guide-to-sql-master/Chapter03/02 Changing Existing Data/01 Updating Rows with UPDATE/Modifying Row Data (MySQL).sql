UPDATE Professor 
SET Name = CONCAT('Prof. ', Name) 
   WHERE ProfessorID > 6;


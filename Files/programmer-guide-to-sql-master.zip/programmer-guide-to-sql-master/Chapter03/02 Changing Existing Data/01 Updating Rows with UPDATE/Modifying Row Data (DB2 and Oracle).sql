UPDATE Professor 
SET Name = 'Prof. ' || Name 
   WHERE ProfessorID > 6;

INSERT INTO Professor (ProfessorID, Name) 
VALUES (7, 'Snail at work');

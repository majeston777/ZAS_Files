CREATE PROCEDURE GetStudents
AS
SELECT StudentID, Name FROM Student;

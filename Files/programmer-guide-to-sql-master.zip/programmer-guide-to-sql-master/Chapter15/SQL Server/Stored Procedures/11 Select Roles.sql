CREATE PROCEDURE RBS_SelectRoles
AS
SELECT RoleId, Description FROM Roles ORDER BY Description
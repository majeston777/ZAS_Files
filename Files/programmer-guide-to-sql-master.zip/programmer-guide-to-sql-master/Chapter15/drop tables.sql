DROP TABLE UserRoles;
DROP TABLE Users;
DROP TABLE RolePermisison;
DROP TABLE Roles;
DROP TABLE Permissions;
DROP TABLE Permissioncategories;
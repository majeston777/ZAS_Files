SELECT ProductID, ProductName, AmountInStock FROM Products
ORDER BY ProductName ASC;

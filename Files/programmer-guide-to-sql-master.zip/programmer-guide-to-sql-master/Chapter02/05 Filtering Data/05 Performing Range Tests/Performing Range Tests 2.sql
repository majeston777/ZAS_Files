SELECT ExamID, SustainedOn, Comments FROM Exam
WHERE SustainedOn BETWEEN '2003-03-20' AND '2003-03-24';

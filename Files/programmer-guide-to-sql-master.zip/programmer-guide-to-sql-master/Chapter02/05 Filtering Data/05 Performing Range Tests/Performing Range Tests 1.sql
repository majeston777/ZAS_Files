SELECT ExamID, SustainedOn, Comments FROM Exam
WHERE SustainedOn >= '2003-03-20'
AND SustainedOn <= '2003-03-24';

SELECT ExamID, SustainedOn, Comments FROM Exam
WHERE SustainedOn NOT BETWEEN '2003-03-20' AND '2003-03-24';

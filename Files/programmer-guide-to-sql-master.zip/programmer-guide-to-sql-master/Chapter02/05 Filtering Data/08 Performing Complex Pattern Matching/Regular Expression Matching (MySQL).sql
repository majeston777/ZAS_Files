SELECT Name FROM Student
WHERE Name REGEXP '^[AM].*r$';

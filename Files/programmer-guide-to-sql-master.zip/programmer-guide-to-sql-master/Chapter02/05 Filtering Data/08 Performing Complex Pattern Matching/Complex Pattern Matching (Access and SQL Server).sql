SELECT Name FROM Student
WHERE Name LIKE '% [a-dw-z]%';

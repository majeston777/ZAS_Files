SELECT StudentID, ExamID, Mark FROM StudentExam
WHERE StudentID IN (2, 7, 3);

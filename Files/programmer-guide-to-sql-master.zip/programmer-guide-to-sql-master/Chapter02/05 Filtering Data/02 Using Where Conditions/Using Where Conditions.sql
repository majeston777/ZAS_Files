SELECT Name FROM Student
WHERE StudentID = 3;

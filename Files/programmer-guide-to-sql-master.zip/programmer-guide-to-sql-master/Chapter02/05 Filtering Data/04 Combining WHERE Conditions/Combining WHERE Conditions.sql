SELECT StudentID, Mark, Comments FROM StudentExam
WHERE ExamID = 1 AND IfPassed = 1;

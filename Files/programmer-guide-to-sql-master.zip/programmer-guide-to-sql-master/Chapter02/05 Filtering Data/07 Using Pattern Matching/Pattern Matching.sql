SELECT StudentID, ExamID, Mark, Comments FROM StudentExam 
WHERE Comments LIKE '%great%';

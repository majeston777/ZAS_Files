SELECT ClassID, Time & ', Room ' & RoomID AS ClassDetails
FROM Class;

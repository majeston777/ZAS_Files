SELECT ClassID,
       CONCAT(Time, ', Room ', RoomID) AS ClassDetails
FROM Class;

INSERT INTO Department (Name, Description) 
   VALUES ('Full Costumes', 'We have the best costumes on the internet!');
INSERT INTO Department (Name, Description) 
   VALUES ('Costume Accessories', 'Accessories and fun items for you.');
INSERT INTO Department (Name, Description) 
   VALUES ('Jokes and Tricks', 'Funny or frightening, but all harmless!');

INSERT INTO Category (DepartmentID, Name, Description) 
   VALUES (1, 'Exotic Costumes', 'Sweet costumes for the party girl:');
INSERT INTO Category (DepartmentID, Name, Description) 
   VALUES (1, 'Scary Costumes', 'Scary costumes for maximum chills:');
INSERT INTO Category (DepartmentID, Name, Description) 
   VALUES (2, 'Masks', 'Items for the master of disguise:');
INSERT INTO Category (DepartmentID, Name, Description) 
   VALUES (3, 'Sweet Stuff', 'Raise a smile wherever you go!');
INSERT INTO Category (DepartmentID, Name, Description) 
   VALUES (3, 'Scary Stuff', 'Scary accessories for the practical joker:');

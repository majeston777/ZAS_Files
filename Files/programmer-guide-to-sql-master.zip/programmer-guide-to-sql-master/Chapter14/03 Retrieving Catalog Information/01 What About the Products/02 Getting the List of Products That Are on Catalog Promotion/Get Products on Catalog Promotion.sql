SELECT Name, Description 
FROM Product 
WHERE OnCatalogPromotion=1
ORDER BY Name;

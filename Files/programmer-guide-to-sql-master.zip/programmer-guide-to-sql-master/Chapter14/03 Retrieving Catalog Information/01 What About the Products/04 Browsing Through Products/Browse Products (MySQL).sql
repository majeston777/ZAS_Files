SELECT ProductID, Name
FROM Product 
ORDER BY ProductID
LIMIT 5,5;

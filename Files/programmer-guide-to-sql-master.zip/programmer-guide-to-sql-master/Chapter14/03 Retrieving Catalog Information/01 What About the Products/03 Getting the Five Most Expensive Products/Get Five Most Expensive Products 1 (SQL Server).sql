SELECT TOP 5 Name, Price 
FROM Product 
ORDER BY Price DESC, Name ASC;

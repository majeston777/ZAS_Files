SELECT Name, Price 
FROM Product 
ORDER BY Price DESC, Name ASC
LIMIT 0,5;

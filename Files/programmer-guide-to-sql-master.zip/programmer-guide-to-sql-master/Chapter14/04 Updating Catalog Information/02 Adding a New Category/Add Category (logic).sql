INSERT INTO Category (DepartmentID, Name, Description)
VALUES (<<DepartmentID>>, <<CategoryName>>, <<CategoryDescription>>);

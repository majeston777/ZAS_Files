VARIABLE C RefCursor
EXEC SearchCatalog (:C, 1, 'Devil', 'Mask')
PRINT C;

USE TestDatabase
GO
EXEC sp_revokedbaccess 'Alice'

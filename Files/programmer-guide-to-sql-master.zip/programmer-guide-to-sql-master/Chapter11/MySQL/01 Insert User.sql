USE mysql
INSERT INTO user VALUES('localhost','Alice',PASSWORD('simplepass'),'Y','Y', 
       'Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y');
FLUSH PRIVILEGES;

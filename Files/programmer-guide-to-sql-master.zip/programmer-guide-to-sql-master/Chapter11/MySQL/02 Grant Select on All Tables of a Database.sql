GRANT SELECT ON InstantUniversity.* 
TO Alice@localhost IDENTIFIED BY 'simplepassword';
FLUSH PRIVILEGES;

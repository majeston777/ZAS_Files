# profile2.sql

# Add a record to the profile table that includes NULL values.
# Run the statements in profile.sql first, then run this query.

INSERT INTO profile (name) VALUES('Juan');

SELECT * FROM profile;

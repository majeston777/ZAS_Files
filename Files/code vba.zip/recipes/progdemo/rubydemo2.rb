#!/usr/bin/ruby
puts "I am a Ruby program."

#!/usr/bin/python
print("I am a Python program.")

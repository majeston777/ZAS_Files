You can get the most recently created AUTO_INCREMENT value from the
server using SELECT LAST_INSERT_ID().  The add_insect.* and
AddInsect.java files illustrate how to get the value using API-specific
client-side methods.

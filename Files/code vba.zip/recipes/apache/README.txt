simple.php is the counterpart to the SimpleServlet servlet discussed in
the JSP intro.  The servlet code is located under the tomcat directory.

Many of the scripts here use HTML-generation and other web-related
utility routines that can be found in the library files located in
the recipes/lib directory.

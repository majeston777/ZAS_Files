cmd-options.pdf
  PDF file that explains the example programs that demonstrate how to
  process command-line options in Perl, Ruby, Python, and Java programs.
